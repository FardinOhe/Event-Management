<?php
include("../view/head.php");
?>



</DOCtype html>
<html>
<title>Contact Us</title>
<style>
	fieldset{
		width: 50%;
		margin: auto;
		margin-top: 5%;
		border: 2px solid black;
		border-radius: 10px;
		background-color: #f2f2f2;
	}
	fieldset p{
		margin-left: 5%;
		text-align: center;
	}
	.fourth{
		margin-bottom: 5%;
	}
	</style>
<h1 style="font-size:30px; text-align:center;margin-top:2rem;"><i>Contact Us On following Addresses</i></h1>
<body>
	
	<fieldset>
		<p style="font-size: 20px"><b><i>1.Foysal Ahmed Sadi</i></b></p>
		<p style="font-size: 15px"><a href="https://www.google.com/">foysalsadi@gmail.com</a></p>
	</fieldset>

	<fieldset>
		<p style="font-size: 20px"><b><i>2.Shahzeb Akbar</i></b></p>
		<p style="font-size: 15px"><a href="https://www.google.com/">shahzeb.akbar69@gmail.com</a></p>
	</fieldset>

	<fieldset>
		<p style="font-size: 20px"><b><i>3.Fardin Ahamed Ohe</i></b></p>
		<p style="font-size: 15px"><a href="https://www.google.com/">fradinohe@gmail.com</a></p>
	</fieldset>

</center>
</body>
</html>
<?php
include("../view/Footer.php");
?>

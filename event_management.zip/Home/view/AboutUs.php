<?php
include("../view/head.php");
?>
<!DOCtype html>
	<html>
	<title>About Us </title>
	<style>
		fieldset{
			width: 50%;
			margin: auto;
			margin-top: 5%;
			border: 2px solid black;
			border-radius: 10px;
			background-color: #f2f2f2;
		}
		fieldset p{
			margin-left: 5%;
			text-align: center;
		}
		.fourth{
			margin-bottom: 5%;
		}

	</style>
	<body>
		<fieldset>
			<p style="font-size: 20px"><b><i>1.Foysal Ahmed Sadi</i></b></p>
			<p style="font-size: 15px">Computer Science and Engineering</p>
			<p style="font-size: 15px"><a href="https://www.aiub.edu/">American International University-Bangladesh(AIUB)</a></p>
		</fieldset>

		<fieldset>
			<p style="font-size: 20px"><b><i>2.Shahzeb Akbar</i></b></p>
			<p style="font-size: 15px">Computer Science and Engineering</p>
			<p style="font-size: 15px"><a href="https://www.aiub.edu/">American International University-Bangladesh(AIUB)</a></p>
		</fieldset>

		<fieldset>
			<p style="font-size: 20px"><b><i>3.Fardin Ahamed Ohe</i></b></p>
			<p style="font-size: 15px">Computer Science and Engineering</p>
			<p style="font-size: 15px"><a href="https://www.aiub.edu/">American International University-Bangladesh(AIUB)</a></p>
		</fieldset>

	
</center>
	</body>
	</html>

<?php
include("../view/footer.php");
?>


